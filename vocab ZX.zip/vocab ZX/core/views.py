import json
import csv
import random
import os
import re
from pathlib import Path
from django.shortcuts import render
from django.http import HttpResponse, JsonResponse, FileResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.cache import never_cache
from django.db.models import Avg
from django.conf import settings as django_settings
from .models import Word, UserScore

# Sample distractor generator for client-side or backend JSON preparation
from .models import generate_distractors

# Audio cache dir — created on first request if missing
AUDIO_CACHE_DIR = Path(django_settings.BASE_DIR) / 'media' / 'audio'
AUDIO_CACHE_DIR.mkdir(parents=True, exist_ok=True)

def home(request):
    # Fetch some stats for the home dashboard
    top_scores = UserScore.objects.all().order_by('-score', '-date_played')[:5]
    total_words = Word.objects.count()
    return render(request, 'core/home.html', {
        'top_scores': top_scores,
        'total_words': total_words,
    })

@never_cache
def mcq_start(request):
    # Seed words if database is empty
    if Word.objects.count() == 0:
        from django.core.management import call_command
        call_command('seed_vocab')
        
    words = list(Word.objects.all())
    random.shuffle(words)
    selected_words = words[:40]
    
    # Prepare JSON list for MCQ
    questions = []
    for word in selected_words:
        choices = [word.spelling] + generate_distractors(word.spelling)
        random.shuffle(choices)
        questions.append({
            'spelling': word.spelling,
            'definition': word.definition,
            'example': word.example_sentence,
            'choices': choices,
            'image_url': word.image_url or ''
        })
        
    return render(request, 'core/mcq.html', {
        'questions_json': json.dumps(questions),
        'total_questions': len(questions)
    })

@never_cache
def typing_start(request):
    if Word.objects.count() == 0:
        from django.core.management import call_command
        call_command('seed_vocab')
        
    words = list(Word.objects.all())
    random.shuffle(words)
    selected_words = words[:40]
    
    questions = []
    for word in selected_words:
        questions.append({
            'spelling': word.spelling,
            'definition': word.definition,
            'example': word.example_sentence,
            'image_url': word.image_url or ''
        })
        
    return render(request, 'core/typing.html', {
        'questions_json': json.dumps(questions),
        'total_questions': len(questions)
    })

def learn_home(request):
    if Word.objects.count() == 0:
        from django.core.management import call_command
        call_command('seed_vocab')
        
    words = Word.objects.all().order_by('spelling')
    return render(request, 'core/learn.html', {
        'words': words
    })

@never_cache
def recorrection_start(request):
    if Word.objects.count() == 0:
        from django.core.management import call_command
        call_command('seed_vocab')
        
    words = list(Word.objects.all())
    random.shuffle(words)
    selected_words = words[:40]
    
    questions = []
    for word in selected_words:
        # Scramble letters
        spelling_chars = list(word.spelling)
        scrambled = spelling_chars.copy()
        attempts = 0
        while scrambled == spelling_chars and len(spelling_chars) > 1 and attempts < 100:
            attempts += 1
            random.shuffle(scrambled)
            
        questions.append({
            'spelling': word.spelling,
            'definition': word.definition,
            'example': word.example_sentence,
            'scrambled_letters': scrambled,
            'image_url': word.image_url or ''
        })
        
    return render(request, 'core/recorrection.html', {
        'questions_json': json.dumps(questions),
        'total_questions': len(questions)
    })

@csrf_exempt
def mcq_submit(request):
    # Save score for MCQ
    return submit_score_internal(request, 'MCQ Spelling')

@csrf_exempt
def typing_submit(request):
    # Save score for Typing
    return submit_score_internal(request, 'Typing Spelling')

@csrf_exempt
def recorrection_submit(request):
    # Save score for Recorrection
    return submit_score_internal(request, 'Spelling Recorrection')

def submit_score_internal(request, mode):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            username = data.get('username', 'Anonymous').strip() or 'Anonymous'
            score = int(data.get('score', 0))
            total = int(data.get('total', 40))
            wpm = data.get('wpm')
            if wpm is not None:
                wpm = float(wpm)
                
            user_score = UserScore.objects.create(
                username=username,
                score=score,
                total_questions=total,
                game_mode=mode,
                wpm=wpm
            )
            
            # Fetch updated leaderboard for this mode
            leaderboard = UserScore.objects.filter(game_mode=mode).order_by('-score', '-date_played')[:10]
            
            # Render updated leaderboard partial
            return render(request, 'core/partials/leaderboard.html', {
                'leaderboard': leaderboard,
                'current_score': user_score,
                'game_mode': mode
            })
        except Exception as e:
            return HttpResponse(f"Error saving score: {str(e)}", status=400)
    return HttpResponse("Invalid request method", status=400)

# Vocabulary File Parser helpers
def parse_csv(file_data):
    decoded_file = file_data.read().decode('utf-8').splitlines()
    reader = csv.DictReader(decoded_file)
    words = []
    for row in reader:
        spelling = row.get('spelling') or row.get('Spelling') or row.get('word') or row.get('Word')
        definition = row.get('definition') or row.get('Definition') or row.get('meaning') or row.get('Meaning')
        example = row.get('example') or row.get('Example') or row.get('example_sentence') or row.get('Example Sentence') or ""
        difficulty = row.get('difficulty') or row.get('Difficulty') or "Medium"
        image_url = row.get('image_url') or row.get('Image URL') or ""
        if spelling and definition:
            words.append({
                'spelling': spelling.strip(),
                'definition': definition.strip(),
                'example_sentence': example.strip(),
                'difficulty': difficulty.strip(),
                'image_url': image_url.strip()
            })
    return words

def parse_json(file_data):
    data = json.loads(file_data.read().decode('utf-8'))
    words = []
    if isinstance(data, list):
        for item in data:
            spelling = item.get('spelling') or item.get('word')
            definition = item.get('definition') or item.get('meaning')
            example = item.get('example_sentence') or item.get('example') or ""
            difficulty = item.get('difficulty') or "Medium"
            image_url = item.get('image_url') or ""
            if spelling and definition:
                words.append({
                    'spelling': spelling.strip(),
                    'definition': definition.strip(),
                    'example_sentence': example.strip(),
                    'difficulty': difficulty.strip(),
                    'image_url': image_url.strip()
                })
    return words

@csrf_exempt
def upload_vocab(request):
    if request.method == 'POST' and request.FILES.get('vocab_file'):
        vocab_file = request.FILES['vocab_file']
        try:
            if vocab_file.name.endswith('.csv'):
                words = parse_csv(vocab_file)
            elif vocab_file.name.endswith('.json'):
                words = parse_json(vocab_file)
            else:
                return HttpResponse('<div class="text-rose-500 font-semibold mt-2">Invalid file format. Upload CSV or JSON.</div>', status=400)
            
            if not words:
                return HttpResponse('<div class="text-rose-500 font-semibold mt-2">No valid word data found in file. Make sure spelling and definition headers exist.</div>', status=400)
                
            created_count = 0
            for item in words:
                obj, created = Word.objects.update_or_create(
                    spelling=item['spelling'],
                    defaults={
                        'definition': item['definition'],
                        'example_sentence': item['example_sentence'],
                        'difficulty': item['difficulty'],
                        'image_url': item['image_url']
                    }
                )
                if created:
                    created_count += 1
                    
            return HttpResponse(f'<div class="text-emerald-500 font-semibold mt-2">Success! Imported {len(words)} words ({created_count} new).</div>')
        except Exception as e:
            return HttpResponse(f'<div class="text-rose-500 font-semibold mt-2">Error processing file: {str(e)}</div>', status=400)
    return HttpResponse('<div class="text-rose-500 font-semibold mt-2">No file uploaded.</div>', status=400)


def speak_word(request, word):
    """
    Returns an MP3 audio file of the word spoken using Google TTS (gTTS).
    Files are cached on disk so each word is generated only once.
    """
    # Sanitize word — only alphanumeric, hyphens, spaces
    safe_word = re.sub(r'[^a-zA-Z0-9\- ]', '', word).strip()[:80]
    if not safe_word:
        return HttpResponse('Invalid word.', status=400)

    cache_filename = re.sub(r'[^a-z0-9\-]', '_', safe_word.lower()) + '.mp3'
    cache_path = AUDIO_CACHE_DIR / cache_filename

    if not cache_path.exists():
        try:
            from gtts import gTTS
            tts = gTTS(text=safe_word, lang='en', tld='com', slow=False)
            tts.save(str(cache_path))
        except Exception as e:
            return HttpResponse(f'TTS generation failed: {e}', status=503)

    response = FileResponse(
        open(cache_path, 'rb'),
        content_type='audio/mpeg'
    )
    response['Cache-Control'] = 'public, max-age=86400'
    return response
