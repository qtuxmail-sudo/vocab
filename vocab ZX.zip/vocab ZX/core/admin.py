from django.contrib import admin
from .models import Word, UserScore

@admin.register(Word)
class WordAdmin(admin.ModelAdmin):
    list_display = ('spelling', 'difficulty', 'example_sentence')
    list_filter = ('difficulty',)
    search_fields = ('spelling', 'definition')
    ordering = ('spelling',)

@admin.register(UserScore)
class UserScoreAdmin(admin.ModelAdmin):
    list_display = ('username', 'game_mode', 'score', 'total_questions', 'wpm', 'date_played')
    list_filter = ('game_mode',)
    search_fields = ('username',)
    ordering = ('-date_played',)
