import random
from django.db import models

def generate_distractors(spelling):
    spelling_lower = spelling.lower()
    if len(spelling_lower) <= 2:
        return [spelling_lower + "s", spelling_lower + "e", spelling_lower + "y"]
        
    vowels = 'aeiou'
    consonants = 'bcdfghjklmnpqrstvwxyz'
    
    distractors = set()
    attempts = 0
    while len(distractors) < 3 and attempts < 150:
        attempts += 1
        word_list = list(spelling_lower)
        strategy = random.randint(1, 6)
        
        if strategy == 1:
            # Swap two adjacent letters
            idx = random.randint(0, len(word_list) - 2)
            word_list[idx], word_list[idx+1] = word_list[idx+1], word_list[idx]
        elif strategy == 2:
            # Double a random letter
            idx = random.randint(0, len(word_list) - 1)
            word_list.insert(idx, word_list[idx])
        elif strategy == 3:
            # Remove a double letter or a random letter
            dups = [i for i in range(len(word_list)-1) if word_list[i] == word_list[i+1]]
            if dups:
                idx = random.choice(dups)
                word_list.pop(idx)
            else:
                idx = random.randint(0, len(word_list) - 1)
                word_list.pop(idx)
        elif strategy == 4:
            # Substitute a vowel
            vowel_indices = [i for i, char in enumerate(word_list) if char in vowels]
            if vowel_indices:
                idx = random.choice(vowel_indices)
                current_v = word_list[idx]
                other_vowels = [v for v in vowels if v != current_v]
                word_list[idx] = random.choice(other_vowels)
            else:
                strategy = 6
        elif strategy == 5:
            # Phonetic replacements
            word_str = "".join(word_list)
            replacements = [
                ("c", "s"), ("s", "c"), ("ph", "f"), ("f", "ph"),
                ("z", "s"), ("s", "z"), ("y", "i"), ("i", "y"),
                ("tion", "shun"), ("sion", "shun"), ("ae", "e"),
                ("ei", "ie"), ("ie", "ei"), ("le", "el"), ("el", "le"),
                ("double", "duble"), ("ou", "u"), ("ea", "ee"), ("ee", "ea")
            ]
            chosen = [rep for rep in replacements if rep[0] in word_str]
            if chosen:
                orig, rep = random.choice(chosen)
                word_str = word_str.replace(orig, rep, 1)
                word_list = list(word_str)
            else:
                strategy = 6
        
        if strategy == 6:
            # Substitute a consonant
            cons_indices = [i for i, char in enumerate(word_list) if char in consonants]
            if cons_indices:
                idx = random.choice(cons_indices)
                current_c = word_list[idx]
                other_cons = [c for c in consonants if c != current_c]
                word_list[idx] = random.choice(other_cons)
                    
        distractor = "".join(word_list)
        # Match case of original spelling
        if spelling.istitle():
            distractor = distractor.title()
        elif spelling.isupper():
            distractor = distractor.upper()
            
        if distractor != spelling and distractor not in distractors and len(distractor) > 1:
            distractors.add(distractor)
            
    # If we couldn't generate 3 unique distractors, fill with simple suffixes
    while len(distractors) < 3:
        suffix = random.choice(['s', 'e', 'y', 'ing'])
        new_dist = spelling + suffix
        if new_dist != spelling:
            distractors.add(new_dist)
        
    return list(distractors)[:3]

class Word(models.Model):
    spelling = models.CharField(max_length=100, unique=True)
    definition = models.TextField()
    example_sentence = models.TextField(blank=True, default='')
    image_url = models.URLField(blank=True, default='')
    difficulty = models.CharField(max_length=20, default='Medium')
    
    def __str__(self):
        return self.spelling

    def get_choices(self):
        distractors = generate_distractors(self.spelling)
        choices = [self.spelling] + distractors
        # Randomize choices order
        random.shuffle(choices)
        return choices

class UserScore(models.Model):
    username = models.CharField(max_length=150)
    score = models.IntegerField()
    total_questions = models.IntegerField(default=40)
    game_mode = models.CharField(max_length=50) # 'mcq', 'typing', 'recorrection'
    wpm = models.FloatField(null=True, blank=True)
    date_played = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.username} - {self.game_mode}: {self.score}/{self.total_questions}"
