from django.core.management.base import BaseCommand
from core.models import Word

class Command(BaseCommand):
    help = 'Seeds the database with initial vocabulary spelling words'

    def handle(self, *args, **kwargs):
        words_data = [
            {
                "spelling": "accommodation",
                "definition": "Room, group of rooms, or building in which someone may live or stay.",
                "example_sentence": "The hotel provides luxury accommodation for its guests.",
                "difficulty": "Hard"
            },
            {
                "spelling": "necessary",
                "definition": "Required to be done, essential.",
                "example_sentence": "It is necessary to wear a helmet while riding a motorcycle.",
                "difficulty": "Easy"
            },
            {
                "spelling": "separate",
                "definition": "Forming or viewed as a unit apart or by itself.",
                "example_sentence": "The two departments are located in separate buildings.",
                "difficulty": "Easy"
            },
            {
                "spelling": "receive",
                "definition": "Be given, presented with, or paid.",
                "example_sentence": "She was delighted to receive an award for her research.",
                "difficulty": "Easy"
            },
            {
                "spelling": "occurrence",
                "definition": "An incident or event.",
                "example_sentence": "The theft was a rare occurrence in the quiet neighborhood.",
                "difficulty": "Medium"
            },
            {
                "spelling": "achievement",
                "definition": "A thing done successfully, typically by effort, courage, or skill.",
                "example_sentence": "Graduating from university was her greatest achievement.",
                "difficulty": "Easy"
            },
            {
                "spelling": "calendar",
                "definition": "A chart or series of pages showing the days, weeks, and months of a year.",
                "example_sentence": "I marked the meeting date on my calendar.",
                "difficulty": "Easy"
            },
            {
                "spelling": "definitely",
                "definition": "Without doubt (used for emphasis).",
                "example_sentence": "I will definitely come to your birthday party.",
                "difficulty": "Medium"
            },
            {
                "spelling": "embarrass",
                "definition": "Cause someone to feel awkward, self-conscious, or ashamed.",
                "example_sentence": "He didn't want to embarrass his friends in public.",
                "difficulty": "Hard"
            },
            {
                "spelling": "experience",
                "definition": "Practical contact with and observation of facts or events.",
                "example_sentence": "She has ten years of experience in software development.",
                "difficulty": "Easy"
            },
            {
                "spelling": "independent",
                "definition": "Free from outside control; not depending on another's authority.",
                "example_sentence": "The colony became an independent nation in 1960.",
                "difficulty": "Medium"
            },
            {
                "spelling": "liaison",
                "definition": "Communication or cooperation which facilitates a close working relationship.",
                "example_sentence": "She acts as a liaison between the police and the community.",
                "difficulty": "Hard"
            },
            {
                "spelling": "possession",
                "definition": "The state of having, owning, or controlling something.",
                "example_sentence": "The laptop is my most valuable possession.",
                "difficulty": "Hard"
            },
            {
                "spelling": "recommend",
                "definition": "Put forward with approval as being suitable for a particular purpose.",
                "example_sentence": "Can you recommend a good restaurant nearby?",
                "difficulty": "Medium"
            },
            {
                "spelling": "weird",
                "definition": "Suggesting something supernatural; uncanny, strange.",
                "example_sentence": "I heard a weird noise coming from the attic.",
                "difficulty": "Easy"
            },
            {
                "spelling": "conscientious",
                "definition": "Wishing to do what is right, especially to do one's work well and thoroughly.",
                "example_sentence": "A conscientious student always double-checks their work.",
                "difficulty": "Hard"
            },
            {
                "spelling": "pronunciation",
                "definition": "The way in which a word is pronounced.",
                "example_sentence": "His spelling is good, but his pronunciation needs improvement.",
                "difficulty": "Medium"
            },
            {
                "spelling": "maintenance",
                "definition": "The process of maintaining or preserving someone or something.",
                "example_sentence": "Car maintenance is crucial for safety and fuel efficiency.",
                "difficulty": "Hard"
            },
            {
                "spelling": "rhythm",
                "definition": "A strong, regular, repeated pattern of movement or sound.",
                "example_sentence": "The dancers moved to the rhythm of the drums.",
                "difficulty": "Hard"
            },
            {
                "spelling": "supersede",
                "definition": "Take the place of a person or thing previously in authority or use.",
                "example_sentence": "The new law will supersede all previous regulations.",
                "difficulty": "Medium"
            },
            {
                "spelling": "pharaoh",
                "definition": "A ruler in ancient Egypt.",
                "example_sentence": "Tutankhamun is a very famous Egyptian pharaoh.",
                "difficulty": "Hard"
            },
            {
                "spelling": "intelligence",
                "definition": "The ability to acquire and apply knowledge and skills.",
                "example_sentence": "Artificial intelligence is transforming many industries.",
                "difficulty": "Medium"
            },
            {
                "spelling": "acknowledgement",
                "definition": "Acceptance or admission of the existence or truth of something.",
                "example_sentence": "We received an acknowledgement of our application.",
                "difficulty": "Medium"
            },
            {
                "spelling": "privilege",
                "definition": "A special right, advantage, or immunity granted to a particular person or group.",
                "example_sentence": "It was a privilege to meet the president in person.",
                "difficulty": "Hard"
            },
            {
                "spelling": "dilemma",
                "definition": "A situation in which a difficult choice has to be made between alternatives.",
                "example_sentence": "He faced a dilemma between telling the truth and protecting his friend.",
                "difficulty": "Medium"
            },
            {
                "spelling": "millennium",
                "definition": "A period of a thousand years.",
                "example_sentence": "The city celebrated its foundation a millennium ago.",
                "difficulty": "Medium"
            },
            {
                "spelling": "gauge",
                "definition": "An instrument or device for measuring magnitude, amount, or contents.",
                "example_sentence": "The fuel gauge showed that the tank was almost empty.",
                "difficulty": "Medium"
            },
            {
                "spelling": "bizarre",
                "definition": "Very strange or unusual.",
                "example_sentence": "He wore a bizarre costume to the party.",
                "difficulty": "Easy"
            },
            {
                "spelling": "bureaucracy",
                "definition": "A system of government in which most decisions are made by state officials.",
                "example_sentence": "The project was delayed due to excessive bureaucracy.",
                "difficulty": "Hard"
            },
            {
                "spelling": "unnecessary",
                "definition": "Not needed; redundant.",
                "example_sentence": "Please avoid making unnecessary purchases.",
                "difficulty": "Medium"
            },
            {
                "spelling": "apparent",
                "definition": "Clearly visible or understood; obvious.",
                "example_sentence": "It became apparent that she was not coming.",
                "difficulty": "Medium"
            },
            {
                "spelling": "collateral",
                "definition": "Something pledged as security for repayment of a loan.",
                "example_sentence": "She used her house as collateral for the business loan.",
                "difficulty": "Medium"
            },
            {
                "spelling": "ecstasy",
                "definition": "An overwhelming feeling of great happiness or joyful excitement.",
                "example_sentence": "They were in ecstasy after winning the championship.",
                "difficulty": "Hard"
            },
            {
                "spelling": "harass",
                "definition": "Subject to aggressive pressure or intimidation.",
                "example_sentence": "The company was warned not to harass its debtors.",
                "difficulty": "Medium"
            },
            {
                "spelling": "irresistible",
                "definition": "Too attractive and tempting to be resisted.",
                "example_sentence": "The chocolate cake on the table was irresistible.",
                "difficulty": "Hard"
            },
            {
                "spelling": "miniature",
                "definition": "Very small of its kind.",
                "example_sentence": "She collects miniature glass animals.",
                "difficulty": "Medium"
            },
            {
                "spelling": "noticeable",
                "definition": "Easily seen or noticed; clear.",
                "example_sentence": "There is a noticeable improvement in your spelling.",
                "difficulty": "Medium"
            },
            {
                "spelling": "outrageous",
                "definition": "Boldly offensive or shocking.",
                "example_sentence": "The pricing of the tickets was absolutely outrageous.",
                "difficulty": "Medium"
            },
            {
                "spelling": "tomorrow",
                "definition": "On the day after today.",
                "example_sentence": "Don't leave for tomorrow what you can do today.",
                "difficulty": "Easy"
            },
            {
                "spelling": "perceive",
                "definition": "Become aware or conscious of; come to realize.",
                "example_sentence": "It is hard to perceive any difference between the two colors.",
                "difficulty": "Medium"
            },
            {
                "spelling": "questionnaire",
                "definition": "A set of questions with a choice of answers for a survey.",
                "example_sentence": "Please fill out this questionnaire about our services.",
                "difficulty": "Hard"
            },
            {
                "spelling": "schedule",
                "definition": "A plan for carrying out a process or procedure.",
                "example_sentence": "I have a very busy schedule this week.",
                "difficulty": "Easy"
            },
            {
                "spelling": "threshold",
                "definition": "A strip forming the bottom of a doorway; a point of entry.",
                "example_sentence": "He stood on the threshold of a new career.",
                "difficulty": "Medium"
            },
            {
                "spelling": "vacuum",
                "definition": "A space entirely devoid of matter.",
                "example_sentence": "Sound cannot travel through a vacuum.",
                "difficulty": "Easy"
            },
            {
                "spelling": "parallel",
                "definition": "Side by side and having the same distance continuously between them.",
                "example_sentence": "The railway lines run parallel to the road.",
                "difficulty": "Easy"
            },
            {
                "spelling": "beginning",
                "definition": "The point in time or space at which something starts.",
                "example_sentence": "This is just the beginning of our project.",
                "difficulty": "Easy"
            },
            {
                "spelling": "cemetery",
                "definition": "A large burial ground, especially one not associated with a church.",
                "example_sentence": "The old cemetery is surrounded by tall pine trees.",
                "difficulty": "Medium"
            },
            {
                "spelling": "colleague",
                "definition": "A person with whom one works in a profession or business.",
                "example_sentence": "My colleague helped me finish the report.",
                "difficulty": "Easy"
            },
            {
                "spelling": "committee",
                "definition": "A group of people appointed for a specific function by a larger body.",
                "example_sentence": "The committee voted in favor of the new proposal.",
                "difficulty": "Hard"
            },
            {
                "spelling": "consensus",
                "definition": "A general agreement.",
                "example_sentence": "The two sides reached a consensus on the contract.",
                "difficulty": "Medium"
            },
            {
                "spelling": "discipline",
                "definition": "The practice of training people to obey rules or a code of behavior.",
                "example_sentence": "Yoga requires a lot of self-discipline.",
                "difficulty": "Medium"
            },
            {
                "spelling": "equipment",
                "definition": "The necessary items for a particular purpose.",
                "example_sentence": "The laboratory has state-of-the-art research equipment.",
                "difficulty": "Easy"
            },
            {
                "spelling": "fiery",
                "definition": "Consisting of fire or burning strongly.",
                "example_sentence": "She gave a fiery speech to the protesters.",
                "difficulty": "Medium"
            },
            {
                "spelling": "foreign",
                "definition": "Of, from, or in a country other than one's own.",
                "example_sentence": "Learning a foreign language opens up new opportunities.",
                "difficulty": "Easy"
            },
            {
                "spelling": "grateful",
                "definition": "Feeling or showing an appreciation of kindness; thankful.",
                "example_sentence": "I am extremely grateful for your assistance.",
                "difficulty": "Easy"
            },
            {
                "spelling": "guarantee",
                "definition": "A formal promise or assurance that certain conditions will be fulfilled.",
                "example_sentence": "The manufacturer offers a two-year guarantee on the product.",
                "difficulty": "Hard"
            },
            {
                "spelling": "height",
                "definition": "The measurement from base to top or of a person standing upright.",
                "example_sentence": "He measured his height against the door frame.",
                "difficulty": "Easy"
            },
            {
                "spelling": "humorous",
                "definition": "Causing lighthearted laughter and amusement.",
                "example_sentence": "She wrote a humorous story about her vacation.",
                "difficulty": "Medium"
            },
            {
                "spelling": "ignorance",
                "definition": "Lack of knowledge or information.",
                "example_sentence": "His comments revealed a complete ignorance of the facts.",
                "difficulty": "Easy"
            },
            {
                "spelling": "immediate",
                "definition": "Occurring or done at once; instant.",
                "example_sentence": "The new rules had an immediate impact on performance.",
                "difficulty": "Medium"
            },
            {
                "spelling": "mischievous",
                "definition": "Causing or showing a fondness for causing trouble in a playful way.",
                "example_sentence": "The mischievous puppy chewed on my slipper.",
                "difficulty": "Hard"
            },
            {
                "spelling": "neighbor",
                "definition": "A person living near or next door.",
                "example_sentence": "Our neighbor kindly watered our plants while we were away.",
                "difficulty": "Easy"
            },
            {
                "spelling": "nucleus",
                "definition": "The central and most important part of an object, movement, or group.",
                "example_sentence": "The cell nucleus contains most of the genetic material.",
                "difficulty": "Easy"
            },
            {
                "spelling": "occasion",
                "definition": "A particular time or instance of an event.",
                "example_sentence": "We dressed up for the special occasion.",
                "difficulty": "Medium"
            },
            {
                "spelling": "queue",
                "definition": "A line or sequence of people or vehicles awaiting their turn.",
                "example_sentence": "We had to wait in a long queue at the supermarket.",
                "difficulty": "Hard"
            }
        ]

        count = 0
        for item in words_data:
            obj, created = Word.objects.get_or_create(
                spelling=item["spelling"],
                defaults={
                    "definition": item["definition"],
                    "example_sentence": item["example_sentence"],
                    "difficulty": item["difficulty"]
                }
            )
            if created:
                count += 1

        self.stdout.write(self.style.SUCCESS(f'Successfully seeded {count} new spelling words.'))
