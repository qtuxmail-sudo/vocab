import io
import json
from django.test import TestCase, Client
from django.urls import reverse
from core.models import Word, UserScore, generate_distractors

class VocabZXTests(TestCase):
    def setUp(self):
        self.client = Client()
        # Create a sample word
        self.word = Word.objects.create(
            spelling="accommodation",
            definition="Room or building for lodging.",
            example_sentence="We found great accommodation in the city center.",
            difficulty="Hard"
        )

    def test_word_creation(self):
        """Test that words are created correctly and str representation works."""
        self.assertEqual(self.word.spelling, "accommodation")
        self.assertEqual(str(self.word), "accommodation")

    def test_distractor_generation(self):
        """Test that generated distractors are unique and do not match the correct word."""
        distractors = generate_distractors(self.word.spelling)
        self.assertEqual(len(distractors), 3)
        self.assertNotIn(self.word.spelling, distractors)
        # Check all distractors are unique
        self.assertEqual(len(set(distractors)), 3)

    def test_get_choices(self):
        """Test get_choices contains correct word and 3 distractors, totaling 4 choices."""
        choices = self.word.get_choices()
        self.assertEqual(len(choices), 4)
        self.assertIn(self.word.spelling, choices)

    def test_score_submission_mcq(self):
        """Test that score submissions for MCQ correctly write to UserScore table."""
        url = reverse('mcq_submit')
        payload = {
            'username': 'TestUser',
            'score': 35,
            'total': 40
        }
        response = self.client.post(
            url,
            data=json.dumps(payload),
            content_type='application/json'
        )
        self.assertEqual(response.status_value, 200) if hasattr(response, 'status_value') else self.assertEqual(response.status_code, 200)
        
        # Verify it was saved
        score_entry = UserScore.objects.filter(username='TestUser', game_mode='MCQ Spelling').first()
        self.assertIsNotNone(score_entry)
        self.assertEqual(score_entry.score, 35)

    def test_score_submission_typing_with_wpm(self):
        """Test that typing score submissions correctly save WPM."""
        url = reverse('typing_submit')
        payload = {
            'username': 'TypistOne',
            'score': 38,
            'total': 40,
            'wpm': 62.5
        }
        response = self.client.post(
            url,
            data=json.dumps(payload),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 200)
        
        score_entry = UserScore.objects.filter(username='TypistOne', game_mode='Typing Spelling').first()
        self.assertIsNotNone(score_entry)
        self.assertEqual(score_entry.score, 38)
        self.assertEqual(score_entry.wpm, 62.5)

    def test_vocab_upload_csv(self):
        """Test uploading custom words via CSV."""
        csv_data = "spelling,definition,example_sentence,difficulty\nrecommend,suggest something,I recommend this,Medium\nweird,strange word,that is weird,Easy\n"
        csv_file = io.BytesIO(csv_data.encode('utf-8'))
        csv_file.name = 'test_vocab.csv'
        
        url = reverse('upload_vocab')
        response = self.client.post(url, {'vocab_file': csv_file})
        self.assertEqual(response.status_code, 200)
        
        # Check database updates
        self.assertTrue(Word.objects.filter(spelling='recommend').exists())
        self.assertTrue(Word.objects.filter(spelling='weird').exists())

    def test_vocab_upload_json(self):
        """Test uploading custom words via JSON."""
        json_data = [
            {
                "spelling": "necessary",
                "definition": "essential or required",
                "example_sentence": "It is necessary to eat.",
                "difficulty": "Easy"
            },
            {
                "spelling": "liaison",
                "definition": "close working relationship",
                "example_sentence": "He acts as a liaison.",
                "difficulty": "Hard"
            }
        ]
        json_file = io.BytesIO(json.dumps(json_data).encode('utf-8'))
        json_file.name = 'test_vocab.json'
        
        url = reverse('upload_vocab')
        response = self.client.post(url, {'vocab_file': json_file})
        self.assertEqual(response.status_code, 200)
        
        self.assertTrue(Word.objects.filter(spelling='necessary').exists())
        self.assertTrue(Word.objects.filter(spelling='liaison').exists())
