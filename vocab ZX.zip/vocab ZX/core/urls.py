from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    
    # MCQ Spelling
    path('mcq/', views.mcq_start, name='mcq_start'),
    path('mcq/submit/', views.mcq_submit, name='mcq_submit'),
    
    # Typing Spelling
    path('typing/', views.typing_start, name='typing_start'),
    path('typing/submit/', views.typing_submit, name='typing_submit'),
    
    # Learn Spelling
    path('learn/', views.learn_home, name='learn_home'),
    
    # Spelling Recorrection
    path('recorrection/', views.recorrection_start, name='recorrection_start'),
    path('recorrection/submit/', views.recorrection_submit, name='recorrection_submit'),
    
    # Settings & Vocabulary Ingestion
    path('upload-vocab/', views.upload_vocab, name='upload_vocab'),

    # Google TTS Audio — returns real MP3 pronunciation
    path('audio/<str:word>/', views.speak_word, name='speak_word'),
]
